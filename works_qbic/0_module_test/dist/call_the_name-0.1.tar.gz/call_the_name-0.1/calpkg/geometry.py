def triangle_area(base, height):
    return base * height / 2
 
def rectangle_area(width, height):
    return width * height
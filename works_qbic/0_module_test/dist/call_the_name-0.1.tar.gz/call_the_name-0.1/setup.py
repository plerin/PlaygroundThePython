from setuptools import find_packages, setup

setup(name='call_the_name',
      version='0.1',
      description='test for using module that multiple files ',
      long_description='long_description',
      url='https://github.com/no',
      author='stunstunstun',
      author_email='zborisz@naver.com',
      license='MIT',
      packages=find_packages(),
      classifiers=[
          'Programming Language :: Python :: 3.6',
          ],
      zip_safe=False)